---
cwd: /Users/shenhaoran/vscode/py/aim-2627-coursework-20904558
---

# 2026-10-05 ~ 2026-10-07 会话记录

## 一、Q4/Q5 报错排查与修复（10-05）

### 背景
用户已完成 Q1–Q3 初版，在 Q4、Q5 的条件判断上反复出错，要求助手定位问题并直接修改文件。

### Q5 发现的四处错误
1. **R5 条件与 R4 完全相同**：`sensor["enemy_frames"][-1] and state == ENGAGE`，因 `and` 交换律，R5（应为当前帧不可见）永远不会被命中。改为 `state == ENGAGE and not visible`。
2. **R6/R7 缺少括号导致优先级错误**：`state == PATROL or state == SUSPECT and visible` 实际按 `PATROL or (SUSPECT and visible)` 解析，PATROL 状态恒为真。加括号修正为 `(PATROL or SUSPECT) and visible`。
3. **R7 中 PATROL 返回了 SUSPECT**：正常巡逻应返回 `SentryState.PATROL`。
4. **enemy_dist 直接与 3 比较**：None 是合法形态，`None <= 3` 抛 TypeError。改为防御式归一：只有非 bool 的 int 才参与贴脸判定，None/非法值按"远"处理。

同时在 decide 开头统一计算 `frames = [bool(x) for ...]`、`visible`、`close`，供 R4/R6 复用。

### Q4 修复
- 删掉了用户多加的"候选都不可行时回退到当前朝向的相反方向"逻辑——题面契约是直接返回 current_facing，且可见测试 test_no_candidate_returns_current_facing 硬性要求。

### 验证
`python -m pytest -k "TestQ4 or TestQ5" -q` → 11 个测试全部通过。

### 关于"卡死"的讨论
用户担心 Q4 无脱困措施会卡死。助手说明职责划分：Q4 是单步纯函数，失速（维持朝向）是允许的；防卡死属于 Q6 的"脱困自由度"，在主循环中检测停滞并主动转向；另有 max_steps=500 硬上限保证不死循环。

## 二、Q6 巡逻任务框架（10-07）

### 规范要点（从题面 PDF 提取）
- 主循环 sense → decide → act；总电量 1000；
- 终止条件：抵达 enemy_pos / max_steps（默认 500）/ 电量耗尽；
- 返回固定契约：steps、collisions、visited_count、found_enemy（与 success 同义）、success；
- 脱困策略自行设计（题面推荐左手沿墙规则）；
- 验收：200 张固定地图成功率 ≥ 92%，平均碰撞 ≤ 1.5，成功案例步数/BFS 最短路 ≤ 1.35；
- report_to_json 需确定性序列化。

### 助手提供的框架设计
- 零碰撞技巧：每步先用 turn_left/right（不耗电）把 facing 对齐到目标方向，再 move_forward；
- 双模式：greedy（调 Q4 next_step_toward，要求下一步曼哈顿距离严格更小）+ wall（左手规则，依次尝试 左转→直行→右转→掉头）；
- 贪心失速切 wall，距离重新可缩短切回 greedy；
- 绕圈保护：沿墙步数超阈值则换手（左↔右），是题面作者 80%→97% 的经验；
- steps 只数 move_forward 次数（与 BFS 最短路口径一致）；
- report_to_json：`json.dumps(stats, sort_keys=True, separators=(",",":"), ensure_ascii=False)`。

## 三、Bonus BFS 实现（10-07）

### 用户要求
直接帮写 bfs_path_length 并列出易错点。

### 实现
- 用 collections.deque，start/target/obstacles 统一转 tuple；
- start == target 返回 0；
- visited 在入队时标记（防止重复入队）；
- 只扩展四个正交方向；
- 目标不可达返回 -1；
- 边界由调用方通过 obstacles 提供（题面规范第 2 条），函数不自行补边界。

### 总结的八大易错点
1. start == target 必须返回 0；
2. 不可达返回 -1（不是 None/False/0）；
3. visited 必须入队时标记，否则指数膨胀卡死；
4. 不要自行加地图边界；
5. 目标点在障碍里时先查 blocked 再查 target；
6. 坐标必须转 tuple（list 不可哈希）；
7. 用 deque 不用 list（popleft O(1)）；
8. 只扩展四方向，不能加对角线。

### 验证
Q6 的 3 个测试（含原 skip 的 test_bfs_disclosed_semantics）全部真正执行并通过。

## 四、Q7 Debug 修复（10-07）

### 任务
src/main/legacy_patrol.py 共 6 处 bug，其中两对互相遮蔽，以各函数 docstring 契约为准修复。

### 修复的 6 处
1. **total_route_meters 单位缺失**：累加的是 segment_length_cm 的厘米却当米返回，放大 100 倍；改为累加厘米后 /100。
2. **calibrate 基线为 None 崩溃**：全负样本/空列表时 `s - None` 抛 TypeError；契约要求返回 0，加 None 判断。
3. **summarize_events off-by-one**：契约"id 不超过 max_id"，`<` 改为 `<=`。
4. **log 可变默认参数**：`history=[]` 跨调用共享；改为默认 None、函数内新建。
5. **run_legacy_sim 终止条件写反**：`stamina > 20: break` 应为 `<= 20` 时终止。
6. **run_legacy_sim 循环变量不自增**：缺 `round_ += 1`，与 Bug 5 互相遮蔽——错误 break 掩盖死循环，两处必须同时修。

### 验证
按契约逐条构造输入验证：路线 7.0 米、calibrate 边界、id 边界、history 独立性、模拟 5 轮 trace（第 3 轮 63）、低体力 2 轮终止于 14。

## 五、README Q7 分析撰写（10-07）

用户已有 Q1–Q5 的简短笔记，助手在 README.md 末尾补充完整的 "## Q7 Debug：昨天还能跑" 小节：
- 6 个 bug 各含"错在哪 / 如何定位 / 修法"三部分；
- 专门说明 Bug 5/6 互相遮蔽的关系；
- 附定位方法总结（契约优先、边界输入、经典陷阱、控制流怀疑）。

## 六、其他讨论

- **settings.json 与 CI 白名单**：`.vscode/settings.json` 不在白名单（只允许 src/main/**、README.md、.agent-sessions/**、.github/workflows/**、.github/settings.yml），只能本地使用不能提交；`.github/settings.yml` 与 `.vscode/settings.json` 是两个不同文件。
- **autopep8 保存时自动格式化**：autopep8 本身是命令行工具，不会在保存时自动运行；需要安装 ms-python.autopep8 扩展并配置 formatOnSave + defaultFormatter。建议直接用 `autopep8 --in-place --recursive src/main/`，与 CI 完全一致。
- **"ERROR: file or directory not found"**：多为终端当前目录不在仓库根目录或路径拼写错误，用 pwd/ls 自查。
- **Q6 的 skip**：skip 的是 test_bfs_disclosed_semantics（Bonus 未实现时 call 辅助捕获 NotImplementedError 自动 skip），实现 BFS 后消失。
- **运行演示命令**：`PYTHONPATH=src python -m main`（Q1 报告 → Q3 机动动画 → Q6 巡逻）。

## 七、当前待办
- 执行 autopep8 修复 __init__.py 历史格式问题；
- 全量 pytest 确认；
- 提交（只 add 白名单文件，勿带 .vscode/）并推送。
